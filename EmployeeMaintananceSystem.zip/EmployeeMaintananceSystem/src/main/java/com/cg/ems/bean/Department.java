package com.cg.ems.bean;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

import lombok.Data;

@Entity

public class Department {
    @Id
    @SequenceGenerator(name="seq1",sequenceName = "seq1", initialValue= 100000, allocationSize=10)
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq1")
	private int deptId;
	private String deptName;
	@OneToMany(fetch = FetchType.LAZY, cascade= CascadeType.ALL,mappedBy="department")
	
	private List<Employee> employee;
	public int getDeptID() {
		return deptId;
	}
	public void setDeptID(int deptID) {
		this.deptId = deptID;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	
}
