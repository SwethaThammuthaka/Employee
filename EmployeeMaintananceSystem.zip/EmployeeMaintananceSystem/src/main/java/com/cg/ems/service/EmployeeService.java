package com.cg.ems.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ems.bean.Employee;
import com.cg.ems.repository.DepartmentRepository;
import com.cg.ems.repository.EmployeeRepository;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;
	private DepartmentRepository departmentrepo;

	public Employee addEmployee(Employee employee) {
		
	employee.setDepartment(departmentrepo.getOne(employee.getDepartment().getDeptID()));
		return employeeRepository.save(employee);
	}

	public Employee getEmployee(int empId) {
		if (ValiadateEmpId(empId))
			return employeeRepository.getOne(empId);
		else
			return null;
	}

	private boolean ValiadateEmpId(int empId) {
		Employee employee = employeeRepository.findOne(empId);
		if (employee != null)
			return true;
		else
		return false;
	}

	public List<Employee> getAllCustomers() {

		return employeeRepository.findAll();
	}

	public Employee updateEmployee(Employee employee) {
		
		return employeeRepository.save(employee);
	}

	

	public void deleteEmployeeDetails(int empId) {
		if (ValiadateEmpId(empId))
			employeeRepository.delete(empId);
	
		
	}
	

}
