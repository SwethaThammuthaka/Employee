package com.cg.ems.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ems.bean.GradeMaster;
import com.cg.ems.repository.GradeMasterRepository;

@Service
public class GradeMasterService {
	@Autowired
	private GradeMasterRepository graderepository;

	public GradeMaster addgrade(GradeMaster grademaster) {
		
		return graderepository.save(grademaster);

	}

	
}