package com.cg.ems.bean;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;


@Entity

public class Employee {
	@Id
	@SequenceGenerator(name = "seq", sequenceName = "seq", initialValue = 100000, allocationSize = 1000)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq")
	private int empId;
//	@Size(min=3,max=25, message="name should be minimum of 3 Characters")
//	@Pattern(regexp="[a-z A-z]")
	private String firstName;
//	@Size(min=3,max=25, message="name should be minimum of 3 Characters")
//	@Pattern(regexp="[a-z A-z]")
	private String lastName;
	
	private String dateofBirth;
	private String dateofJoining;
	private String empGrade;
	@Size(max=50, message="name should be minimum of 3 Characters")
	@Pattern(regexp="[a-z A-z]")
//	@NotNull(message="Designation Required")
	private String designation;
	private String basic;
	private String gender;
	private String maritalStatus;
//   @Size(min=3,max=25, message="Address Required")
//	@Pattern(regexp="[a-z A-z]")
	private String address;
	private String contactNumber;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "deptId")
	private Department department;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "empGradeCode")
	private GradeMaster grademaster;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDateofBirth() {
		return dateofBirth;
	}

	public void setDateofBirth(String dateofBirth) {
		this.dateofBirth = dateofBirth;
	}

	public String getDateofJoining() {
		return dateofJoining;
	}

	public void setDateofJoining(String dateofJoining) {
		this.dateofJoining = dateofJoining;
	}

	public String getEmpGrade() {
		return empGrade;
	}

	public void setEmpGrade(String empGrade) {
		this.empGrade = empGrade;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getBasic() {
		return basic;
	}

	public void setBasic(String basic) {
		this.basic = basic;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public GradeMaster getGrademaster() {
	
		return grademaster;
	}

	public void setGrademaster(GradeMaster findOne) {
		this. grademaster =  grademaster;
	}

	
}