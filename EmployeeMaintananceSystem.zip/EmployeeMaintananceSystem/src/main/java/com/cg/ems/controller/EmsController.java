package com.cg.ems.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ems.bean.Department;
import com.cg.ems.bean.Employee;
import com.cg.ems.bean.GradeMaster;
import com.cg.ems.service.DepartmentService;
import com.cg.ems.service.EmployeeService;
import com.cg.ems.service.GradeMasterService;




@RestController
public class EmsController {

@Autowired
private EmployeeService employeeService;


@RequestMapping( value="/addemployee",method= RequestMethod.POST)
public Employee addemployee(@RequestBody Employee employee)  {

		return employeeService.addEmployee(employee);

	}
@RequestMapping("/employee")    
public List<Employee> getAllCustomers() throws Exception {
	return employeeService.getAllCustomers();
	}

@RequestMapping(value="/employee/{empId}",method= RequestMethod.GET)
public Employee getEmployeedetails(@PathVariable int empId) {
	return employeeService.getEmployee(empId);
}



@RequestMapping(value = "/employee/{empId}", method = RequestMethod.PUT)
public Employee updateEmployee(@RequestBody Employee employee) {
	return employeeService.updateEmployee(employee);
}



@RequestMapping(value = "/deleteemployee/{empId}", method = RequestMethod.DELETE)
public void deleteCustomerDetails(@PathVariable int empId) {
	employeeService.deleteEmployeeDetails(empId);

}


@Autowired
private DepartmentService dservice;

@RequestMapping( value="/adddepartment",method= RequestMethod.POST)
public Department adddepartment(@RequestBody Department department)  {

		return dservice.adddepartment(department);

	}

@RequestMapping("/department")    
public List<Department> getalldepartments() throws Exception {
	return dservice.getalldepartments();
	}


@Autowired
private GradeMasterService gservice;

@RequestMapping( value="/addgrade",method= RequestMethod.POST)
public GradeMaster addgrade(@RequestBody GradeMaster grademaster)  {

		return gservice.addgrade(grademaster);

	}






}
